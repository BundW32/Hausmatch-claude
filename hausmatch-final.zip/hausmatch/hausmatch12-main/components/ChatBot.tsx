import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';

interface Message {
  role: 'user' | 'assistant';
  text: string;
}

const GEMINI_API_KEY = 'AQ.Ab8RN6I3Q-VQPU3hcvNJLZ7FFGmlchp6F0Z1_vfG3gK03lfRag';

const SYSTEM_PROMPT = `Du bist Max, ein erfahrener Immobilienexperte und digitaler Assistent der Plattform HausMatch.

DEINE EXPERTISE umfasst:
- Hausverwaltung (WEG-Verwaltung, Mietverwaltung, Sondereigentumsverwaltung)
- Deutsches Mietrecht und Wohnungseigentumsrecht (WEG)
- Immobilienfinanzierung: Kredite, Zinsen, Tilgung, KfW-Förderungen, BAFA
- Renditeberechnungen (Brutto-, Netto- und Eigenkapitalrendite)
- Immobilienkauf und -verkauf in Deutschland
- Energetische Sanierung und staatliche Förderprogramme (BEG, BAFA)
- Grunderwerbsteuer, Notar- und Maklerkosten nach Bundesland
- Nebenkosten, Betriebskostenabrechnung, Hausgeld
- Mieterhöhungen, Modernisierungsumlage, Kündigung
- WEG-Reform 2020, aktuelle Gesetzgebung
- Markttrends in deutschen Immobilienmärkten

DEIN KOMMUNIKATIONSSTIL:
- Professionell aber verständlich — keine Fachchinesisch ohne Erklärung
- Konkret mit Zahlen und Beispielen wo möglich
- Strukturiert: bei komplexen Themen mit Aufzählungen arbeiten
- Empathisch — du verstehst, dass Immobilien oft große Investitionen bedeuten
- Proaktiv: weise auf häufige Fehler und wichtige Aspekte hin, die der Nutzer vielleicht vergessen hat

WICHTIGE REGELN:
1. IMMER am Ende von rechtlichen oder finanziellen Antworten den Disclaimer hinzufügen: "⚠️ KI-Hinweis: Diese Antwort ist eine allgemeine Information und kein Ersatz für rechtliche oder steuerliche Beratung."
2. Bei sehr spezifischen Rechtsfragen (z.B. laufende Rechtsstreitigkeiten, individuelle Vertragsgestaltung) empfiehl ausdrücklich einen Fachanwalt für Mietrecht oder Immobilienrecht.
3. Bei Finanzierungsfragen empfiehl ergänzend den HausMatch-Kreditrechner unter /kreditrechner.
4. Du kennst die HausMatch-Plattform: Netzwerk (/network), Forum (/forum), Ratgeber (/ratgeber), Kreditrechner (/kreditrechner).
5. Antworte IMMER auf Deutsch.
6. Halte Antworten kompakt (max. 4 Absätze oder 6 Aufzählungspunkte) — außer der Nutzer fragt explizit nach mehr Details.
7. Erfinde keine konkreten Gerichtsurteile oder Gesetzesstellen — weise stattdessen auf die relevante Gesetzesgrundlage allgemein hin.`;

const ChatBot = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: 'Hallo! Ich bin Max, Ihr Immobilien-Assistent von HausMatch. 🏠\n\nIch helfe Ihnen bei Fragen zu Hausverwaltung, Mietrecht, Finanzierung und Investment. Was möchten Sie wissen?\n\n⚠️ Hinweis: Ich bin eine KI. Meine Antworten sind allgemeine Informationen und kein Ersatz für rechtliche oder steuerliche Beratung.'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open, messages]);

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const userMsg: Message = { role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const apiKey = GEMINI_API_KEY || import.meta.env.VITE_GEMINI_API_KEY || '';

      if (!apiKey) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          text: 'Der KI-Chat ist aktuell nicht konfiguriert. Bitte nutzen Sie unser Forum für Ihre Fragen.\n\n⚠️ KI-Hinweis: Diese Antwort ist eine allgemeine Information und kein Ersatz für rechtliche oder steuerliche Beratung.'
        }]);
        setLoading(false);
        return;
      }

      const ai = new GoogleGenAI({ apiKey });

      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      }));

      const chat = ai.chats.create({
        model: 'gemini-2.0-flash',
        history,
        config: {
          systemInstruction: SYSTEM_PROMPT,
        }
      });

      const response = await chat.sendMessage({ message: text });
      const replyText = response.text || 'Entschuldigung, ich konnte keine Antwort generieren.';

      setMessages(prev => [...prev, { role: 'assistant', text: replyText }]);
    } catch (err) {
      console.error('Chat error:', err);
      setMessages(prev => [...prev, {
        role: 'assistant',
        text: 'Es tut mir leid, ich konnte Ihre Anfrage gerade nicht verarbeiten. Bitte versuchen Sie es erneut.\n\n⚠️ KI-Hinweis: Diese Antwort ist eine allgemeine Information und kein Ersatz für rechtliche oder steuerliche Beratung.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const suggestions = [
    'Was kostet eine Hausverwaltung?',
    'Wie berechne ich die Rendite?',
    'Mieterhöhung — was muss ich beachten?'
  ];

  const formatText = (text: string) => {
    return text.split('\n').map((line, i) => {
      if (line.startsWith('⚠️')) {
        return (
          <p key={i} style={{ fontSize: '10px', color: '#92400e', background: '#fef3c7', borderRadius: '6px', padding: '4px 8px', marginTop: '6px' }}>
            {line}
          </p>
        );
      }
      if (line === '') return <br key={i} />;
      return <span key={i} style={{ display: 'block' }}>{line}</span>;
    });
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-blue-600 text-white rounded-full shadow-2xl shadow-blue-300/60 hover:bg-blue-700 transition-all hover:scale-110 active:scale-95 flex items-center justify-center"
        aria-label="KI-Immobilienberater öffnen"
      >
        {open ? (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
        ) : (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
        )}
      </button>

      {/* Chat Window */}
      {open && (
        <div className="fixed bottom-24 right-4 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-96 max-h-[80vh] flex flex-col bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
          {/* Header */}
          <div className="bg-blue-600 px-5 py-4 flex items-center gap-3">
            <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center text-white font-black text-sm">M</div>
            <div>
              <div className="text-white font-black text-sm">Max — Immobilien-KI</div>
              <div className="text-blue-200 text-xs font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>
                Powered by Gemini · Nur allgemeine Info
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="ml-auto text-white/60 hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          {/* Disclaimer Banner */}
          <div className="bg-amber-50 border-b border-amber-100 px-4 py-2 flex items-start gap-2">
            <svg className="w-3.5 h-3.5 text-amber-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
            <p className="text-[10px] text-amber-700 font-medium leading-snug">
              KI-generierte Antworten — keine Rechtsberatung. Bei rechtlichen Fragen immer einen Fachanwalt konsultieren.
            </p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0 max-h-80">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[88%] px-4 py-3 rounded-2xl text-sm font-medium leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-blue-600 text-white rounded-br-sm'
                    : 'bg-slate-100 text-slate-800 rounded-bl-sm'
                }`}>
                  {msg.role === 'assistant' ? formatText(msg.text) : msg.text}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-100 px-4 py-3 rounded-2xl rounded-bl-sm flex gap-1.5 items-center">
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Suggestions */}
          {messages.length === 1 && (
            <div className="px-4 pb-2 flex flex-wrap gap-2">
              {suggestions.map(s => (
                <button
                  key={s}
                  onClick={() => { setInput(s); inputRef.current?.focus(); }}
                  className="text-xs bg-slate-50 border border-slate-200 text-slate-600 font-medium px-3 py-1.5 rounded-full hover:border-blue-300 hover:text-blue-600 transition-all"
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="border-t border-slate-100 p-3 flex gap-2 items-center">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Frage stellen..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-medium text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              disabled={loading}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || loading}
              className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center hover:bg-blue-700 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 flex-shrink-0"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatBot;
